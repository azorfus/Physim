#ifndef PHYSIM_H
#define PHYSIM_H

#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Menu_Bar.H>
#include <FL/Fl_Menu_Item.H>
#include <FL/Fl_Text_Display.H>
#include <FL/Fl_Text_Editor.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/fl_draw.H>
#include <FL/fl_ask.H>
#include <FL/Fl_Scroll.H>
#include <stdio.h>
#include <vector>
#include "particle.h"
#include "toolbar.h"
#include "terminal.h"

class Scene;
class Physim : public Fl_Double_Window
{
	public:
		Physim(int w, int h, const char* title);
		~Physim();
		void update();
		Fl_Offscreen offscreen_buffer = 0;
		Scene* scene;
		Fl_Scroll* scr; 
		Fl_Menu_Bar* menubar;
		Toolbar* toolbar;
		std::vector <Particle> particles;
		int pcount;
};
#endif // PHYSIM_H
