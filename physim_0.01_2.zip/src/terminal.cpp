#include "terminal.h"

Terminal::Terminal(int w, int h, const char* title) : Fl_Double_Window(w, h, title)
{
	text_win = new Fl_Text_Editor(10, 10, w-20, h-20);
	text_win->textsize(12);
	text_buff = new Fl_Text_Buffer();
	text_win->buffer(text_buff);
	text_buff->append("Type 'help' for documentation\n>");
	text_win->kf_down(0, text_win);
	text_win->kf_end(0, text_win);
}

Terminal::~Terminal()
{
	delete text_win;
}

