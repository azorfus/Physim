#include "particle.h"
#include "physim.h"

Particle::Particle(Physim* parent, int gx, int gy, int gr, char* label)
{
	x = gx;
	y = gy;
	r = gr;
	velocity_y = 2;
	fl_begin_offscreen(parent->offscreen_buffer);
	fl_color(FL_YELLOW);
	fl_pie(gx, gy, 10, 10, 0, 360);
	fl_color(FL_BLACK);
	fl_arc(gx, gy, 10, 10, 0, 360);
	fl_end_offscreen();
	parent->redraw();
}

void Particle::update(Physim* parent)
{
	step_y = y + velocity_y*0.01 + 0.05*-100*0.02*0.02;
	if(step_y>590)
	{
		velocity_y *= -1;
		velocity_y += 10;
	}
	else
	{
		velocity_y = velocity_y + 100*0.02;
		y=step_y;
	}
	fl_begin_offscreen(parent->offscreen_buffer);
	fl_color(FL_YELLOW);
	fl_pie(x, y, 10, 10, 0, 360);
	fl_color(FL_BLACK);
	fl_arc(x, y, 10, 10, 0, 360);
	fl_end_offscreen();
	parent->redraw();
}
