#include "physim.h"
#include "scene.h"

static Physim* physim = new Physim(600, 400, "physim");

void scr_update()
{
	fl_begin_offscreen(physim->offscreen_buffer);
	fl_color(FL_WHITE);
	fl_rectf(0, 0, 1000, 1000);
	fl_color(128, 128, 0);
	fl_rectf(0, 600, 1000, 1000);
	fl_end_offscreen();
}

void callback(void*)
{
	scr_update();
	physim->update();
	Fl::repeat_timeout(0.016, callback);
}

void add_particle(Fl_Widget*)
{
	if(physim->toolbar->particle.state == false) 
		physim->toolbar->particle.state = true;
	else
		physim->toolbar->particle.state = false; 
}

void run_simulation(Fl_Widget*)
{
	if(physim->toolbar->control.state == false) 
	{
		physim->toolbar->control.state = true;
    	Fl::add_timeout(0.016, callback);
	}
	else
	{
		physim->toolbar->control.state = false; 
		Fl::remove_timeout(callback);	
	}
}

int main(int argc, char **argv)
{
	Fl::add_handler([](int event)->int {
		return event == FL_SHORTCUT && Fl::event_key() == FL_Escape;
 	});
	physim->toolbar->control.button->callback(run_simulation);
	physim->toolbar->particle.button->callback(add_particle);
	return Fl::run();
}
