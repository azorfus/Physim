#include "physim.h"
#include "scene.h"
#include "particle.h"

static Terminal* terminal;
bool terminal_on = false;

void menu_cb(Fl_Widget*w, void*)
{
	Fl_Menu_* m = (Fl_Menu_*)w;
	const Fl_Menu_Item* mw = m->mvalue();
	const char* ml = mw->label();
	if(strncmp(ml, "&Terminal", 9)==0)
	{
		if(terminal_on == false)
		{
			terminal_on = true;
			if(!terminal)
			{
				terminal = new Terminal(400, 200, "Terminal");
			}
			terminal->show();
		}
		else
		{
			terminal_on = false;
			terminal->hide();
		}
	}
}

void quit(Fl_Widget*, void*)
{
	exit(0);
}

void about(Fl_Widget*, void*)
{
	Fl_Double_Window* about = new Fl_Double_Window(300, 150, "About Physim");
	about->set_modal();
	Fl_Box* detail = new Fl_Box(0, 0, 300, 150, "Physim Version 0.01 Alpha (Unregistered)\nCopyrights(C) 2021\n\nPhysics and structure\nsimulation software\n\nAuthor: Azorfus (azorfus at gmail.com)");
	detail->box(FL_DOWN_BOX);
	detail->color((Fl_Color)53);
	detail->labelfont(4);
	detail->labelsize(12);
	detail->align(Fl_Align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE));
	about->show();
}


Fl_Menu_Item menutable[] = {
	{"&File", 0, 0, 0, FL_SUBMENU},
		{"&About", 0, (Fl_Callback *)about},
		{"&Quit", 0, (Fl_Callback *)quit},
		{0},
	{"&View", 0, 0, 0, FL_SUBMENU},
		{"&Terminal", 0, 0, (void *)0, FL_MENU_TOGGLE},
		{"&Command Window", 0, 0, (void *)1, FL_MENU_TOGGLE},
		{0}
};

Physim::Physim(int w, int h, const char* title) : Fl_Double_Window(0, 0, w, h, title)
{
	menubar = new Fl_Menu_Bar(0, 0, 640, 20);
	menubar->callback(menu_cb);
	menubar->menu(menutable);
	pcount = 0;
	scr = new Fl_Scroll(0, 45, 600, 355);
    scene = new Scene(-100, 45, 600, 355);
	scene->parent = this;
	scr->end();
	toolbar = new Toolbar(0, 20, 600, 25);
	this->size_range(600, 400, 600, 400);
	this->show();
	scene->draw();
}

Physim::~Physim()
{
	delete terminal;
	delete scene;
	delete scr;
	delete menubar;
	delete toolbar;
	delete this;
}

void Physim::update()
{
	for(int i=0;i<pcount;i++)
	{
		if(i<=particles.size())
		{
			particles[i].update(this);
		}
	}
}

