#ifndef TERMINAL_H
#define TERMINAL_H

#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Text_Editor.H>
#include <FL/Fl_Text_Buffer.H>

class Terminal : public Fl_Double_Window
{
	public:
		Terminal(int w, int h, const char* title);
		~Terminal();
		Fl_Text_Editor* text_win;
		Fl_Text_Buffer* text_buff;
};


#endif // TERMINAL_H
