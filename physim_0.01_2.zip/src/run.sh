g++ -g -Wall -Wextra -lfltk -L/usr/X11/lib -lX11 ./*.cpp  -o physim && ./physim
